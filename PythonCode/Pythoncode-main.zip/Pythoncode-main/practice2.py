# lab Viva
#17182103317 Md Ikbal Hosen

print("lab Viva")

